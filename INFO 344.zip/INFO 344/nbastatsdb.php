<?php
	$username = 'info344user';
	$password = 'password';

	if(isset($_REQUEST["playername"])) {
		$query = $_REQUEST["playername"];
		if($_REQUEST["playername"] != "") {
			try {
			$conn = new PDO ('mysql:host=nbagametime.cfqdyfpk1tgr.us-west-2.rds.amazonaws.com;dbname=nbastats', $username, $password);
			$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

			$rows = $conn->prepare("SELECT * FROM statstable WHERE PlayerName LIKE '%{$query}%'");
			$rows->execute();
		
			} catch(PDOException $e) {
				echo 'ERROR:' . $e->getMessage();
			}
		} 
	}
		
		
