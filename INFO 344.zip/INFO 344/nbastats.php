<?php
	include 'nbastatsdb.php';
	class Player {

		private $PlayerName, $GP, $FGP, $TPP, $FTP, $PPG;

		public function __construct($playername, $gp, $fgp, $tpp, $ftp, $ppg) {
			$this->PlayerName = $playername;
			$this->GP = $gp;
			$this->FGP = $fgp;
			$this->TPP = $tpp;
			$this->FTP = $ftp;
			$this->PPG = $ppg;
		}
		
		public function getPlayerName() {
			return $this->PlayerName;
		}

		public function getGP() {
			return $this->GP;
		}

		public function getFGP() {
			return $this->FGP;
		}

		public function getTPP() {
			return $this->TPP;
		}

		public function getFTP() {
			return $this->FTP;
		}

		public function getPPG() {
			return $this->PPG;
		}
	}
?>
<!DOCTYPE HTML>
<html>
	<head>
		<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
		<link rel="stylesheet" type ="text/css" href="nbastats.css">
		<title>NBA Players and Stats</title>
	</head>
	<body>
		<img class="logo" src="http://desktopwallpapers.biz/wp-content/uploads/2014/09/Nba-Logo-New.jpg"/ alt"nba logo">
		<div class="container">
			<div class="input">
				<form method="GET" class="form-inline">
					<input class="form-control" type="text" name="playername" size="75" placeholder="Enter player name...">
					<button type="submit" value="Search" class="btn btn-default" id="button">Search</button>
				</form>
			</div>
		</div>
		<div class="displayresults">

		<?php
			if(isset($_REQUEST["playername"]) && $_REQUEST["playername"] != "" && $_REQUEST["playername"] != " ") {
				$playerArray = array();

				foreach($rows as $row) {
					$player = new Player($row[0], $row[1], $row[2], $row[3], $row[4], $row[5]);
					array_push($playerArray, $player);
				}	
		?>



		<?php
			foreach($playerArray as $player) {
				$name = $player->getPlayerName();
				$gp = $player->getGP();
				$fgp =$player->getFGP();
				$tpp = $player->getTPP();
				$ftp = $player->getFTP();
				$ppg = $player->getPPG();
				$imgurl = strtolower($name);
				$imgurl = str_replace(" ", "_", $imgurl);
				$url = "http://i.cdn.turner.com/nba/nba/.element/img/2.0/sect/statscube/players/large/" . $imgurl . ".png";
		?>
			<div class="container">
				<div class="displaybox">
					<div class="boxleft">
						<img src=<?php echo $url?> alt="player" />
						<h2><?php echo $name?></h2>
					</div>
					<div class="boxright">
						<table class="table table-striped" id="table">
							<tr>
								<th>GP</th><th>FGP</th><th>TPP</th><th>FTP</th><th>PPG</th>	
							</tr>
							<tr>
								<td><?php echo $gp ?></td>
								<td><?php echo $fgp . "%" ?></td>
								<td><?php echo $tpp . "%" ?></td>
								<td><?php echo $ftp . "%" ?></td>
								<td><?php echo $ppg ?></td>
							</tr>
						</table>
					</div>
			
					
				</div>
			</div>
			
		<?php
					}
			} else {
		?>
			<div class="container">
				<div class="displaybox">
					<h2>Enter a player name.</h2>
				</div>
			</div>
		<?php
			}
		?>
		</div>
	</body>
</html>

